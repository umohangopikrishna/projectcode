import { Component, Input, OnInit } from '@angular/core';
import { MyServicesService } from 'src/app/HttpServices/my-services.service';

@Component({
  selector: 'app-update-doner-comp',
  templateUrl: './update-doner-comp.component.html',
  styleUrls: ['./update-doner-comp.component.css']
})
export class UpdateDonerCompComponent implements OnInit {

  @Input() donarData: any;
  weight: number;
  age: number;
  phoneNumber: string;
  address: string;
  pHLevel: string;
  pressure: string;
  bloodgroup: string;
  donarName: string;

  formData: any = {
    weight: 0,
    age: 0,
    phoneNumber: '',
    address: '',
    pHLevel: '',
    pressure: '',
    bloodgroup: '',
    donarName: '',
    id: 0
  };

  loader: boolean;
  constructor(private httpReq: MyServicesService) {
    this.bloodgroup = '';
    this.loader = false;
  }

  ngOnInit(): void {

    this.weight = this.donarData.weight;
    this.age = this.donarData.age;
    this.phoneNumber = this.donarData.phoneNumber ;
    this.address = this.donarData.address;
    this.pHLevel = this.donarData.pHLevel;
    this.pressure = this.donarData.pressure;
    this.bloodgroup = this.donarData.bloodgroup;
    this.donarName = this.donarData.donarName;
  }
  updateUser() {
    this.loader = true;
    this.formData.weight = this.weight;
    this.formData.age = this.age;
    this.formData.phoneNumber = this.phoneNumber;
    this.formData.address = this.address;
    this.formData.pHLevel = this.pHLevel;
    this.formData.pressure = this.pressure;
    this.formData.bloodgroup = this.bloodgroup;
    this.formData.donarName = this.donarName;
    this.formData.id = this.donarData.id;
    console.log(this.formData);

    this.httpReq.putReq('http://localhost:8080/updateDoner/', this.formData).subscribe(
      response => {
        console.log(response);
        this.loader = false;
      },
      err => {
        this.loader = false;
      }
    );

  }

}
