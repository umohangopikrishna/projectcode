import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { MyServicesService } from '../HttpServices/my-services.service';

@Component({
  selector: 'app-login-comp',
  templateUrl: './login-comp.component.html',
  styleUrls: ['./login-comp.component.css']
})
export class LoginCompComponent implements OnInit {

  UserId: string;
  UserPassword: string;

  typeUser: string;
  imgIcon: string;
  logStatus: boolean;
  loader: boolean;

  emptyvalueValidation: boolean;

  constructor(private routeActive: ActivatedRoute, private router: Router, private httpReq: MyServicesService,
              private service: MyServicesService)
  {
    this.logStatus = false;
    this.loader = false;
    this.emptyvalueValidation = false;
   }

  ngOnInit(): void {
    this.routeActive.params.subscribe(params => {
      console.log(params);
      this.typeUser = params.typeUser;
      if (this.typeUser === 'user') {
        this.imgIcon = '/assets/customer.jpg';

      }
      else if (this.typeUser === 'admin') {
        this.imgIcon = '/assets/admin.png';
      }
      else
      {
        this.router.navigate([''], { replaceUrl: true });
       }
    });
  }

  UserLogin(formData: any) {

    this.loader = true;

    if (this.UserId !== null && this.UserPassword !== null) {
      this.emptyvalueValidation = false;
      this.httpReq.getReq('http://localhost:8080/UserLogin/' + this.UserId + '/' + this.UserPassword + '/' + this.typeUser).subscribe(
        response => {
          this.logStatus = !Boolean(response);
          console.log(response);

          if (!this.logStatus) {

            if (this.typeUser === 'admin') {
              this.router.navigate(['/adminHome'], { replaceUrl: true });
            } else {
              this.router.navigate(['/userHome'], { replaceUrl: true });
              // user home page logic;
            }

            sessionStorage.setItem('userId', this.UserId);
            sessionStorage.setItem('checkSequencePath', 'true');
            this.service.logsignal.emit(false);
          }
          this.loader = false;
        },
        err => {
          this.loader = false;
        });
      console.log(this.UserId);
    }
    else
    {
      this.emptyvalueValidation = true;
     }
  }

  forgetpasswordFun()
  {
    this.router.navigate(['forgetpassword/' + this.typeUser], { replaceUrl: true });
   }

}
