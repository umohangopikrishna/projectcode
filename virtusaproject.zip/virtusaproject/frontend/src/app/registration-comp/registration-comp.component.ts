import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MyServicesService } from '../HttpServices/my-services.service';

@Component({
  selector: 'app-registration-comp',
  templateUrl: './registration-comp.component.html',
  styleUrls: ['./registration-comp.component.css']
})
export class RegistrationCompComponent implements OnInit {


  firstName: string;
  lastName: string;
  password: string;
  confirmPassword: string;
  gmailId: string;
  phoneNumber: number;
  userId: string;


  formData: any = { firstName: '', lastName: '', password: '', gmailId: '', phoneNumber: '', typeUser: '', userID: '' };
  validationData: any = [false, false];

  typeUser: string;
  imgIcon: string;
  resultFlage: boolean;

  fieldValidation: any = [false, false, false, false, false, false, false, false];

  loader: boolean;
  constructor(private routeActive: ActivatedRoute, private httpObj: MyServicesService) { }

  ngOnInit(): void {
    this.loader = false;
    this.resultFlage = true;
    this.routeActive.params.subscribe(params => {
      console.log(params);
      this.typeUser = params.typeUser;
      if (params.typeUser === 'user') {
        // this.typeUser = 0;
        this.imgIcon = '/assets/customer.jpg';
      }
      else {
       // this.typeUser = 1;
        this.imgIcon = '/assets/admin.png';
      }
    });
  }
  UserRegistration(formData: any)
  {


    this.fieldValidation[0] = this.firstName == null || this.firstName === '';
    this.fieldValidation[1] = this.lastName == null || this.lastName === '';
    this.fieldValidation[2] = this.phoneNumber == null || String(this.phoneNumber).length !== 10;
    this.fieldValidation[3] = this.gmailId == null || !this.gmailId.includes('@gmail.com');
    this.fieldValidation[4] = this.userId == null;
    this.fieldValidation[5] = this.password == null || String(this.password).length < 9;
    this.fieldValidation[6] = this.confirmPassword == null || this.confirmPassword.trim() !== this.password;
    console.log(this.fieldValidation);
    console.log(String(this.password).length);
    if (!this.fieldValidation[0] && !this.fieldValidation[1] &&
      !this.fieldValidation[2] && !this.fieldValidation[3] && !this.fieldValidation[4] &&
      !this.fieldValidation[5] && !this.fieldValidation[6]) {

      this.formData.firstName = this.firstName.trim();
      this.formData.lastName = this.lastName.trim();
      this.formData.password = this.password.trim();
      this.formData.phoneNumber = String(this.phoneNumber);
      this.formData.gmailId = this.gmailId.trim();
      this.formData.typeUser = this.typeUser;
      this.formData.userID = this.userId.trim();
      this.loader = true;
      this.httpObj.postReq('http://localhost:8080/UserRegistration/', this.formData).subscribe(
        response => {
          console.log(response);
          this.validationData = response;
          this.loader = false;
          this.resultFlage = this.validationData[0] && this.validationData[1] && this.validationData[2];
        },
        err => {
          this.loader = false;
        });
    }
   }

}
