import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-result-comp',
  templateUrl: './result-comp.component.html',
  styleUrls: ['./result-comp.component.css']
})
export class ResultCompComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
