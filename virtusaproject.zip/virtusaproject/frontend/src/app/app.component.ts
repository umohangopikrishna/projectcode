import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { MyServicesService } from './HttpServices/my-services.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'BloodBankFrontEnd';
  logsignal: boolean;
  constructor(private service: MyServicesService , private router: Router)
  {
    this.logsignal = true;
    this.service.logsignal.subscribe(
      signal => {
        this.logsignal = signal;
      });
    sessionStorage.setItem('checkSequencePath', 'false');

  }
  registerNavigate(typeUser: any)
  {
    this.router.navigate(['register/' + typeUser], { replaceUrl: true });
  }
  loginNavigate(typeUser: any)
  {
    this.router.navigate(['login/' + typeUser], { replaceUrl: true });
  }
  logout()
  {
    this.logsignal = true;
    this.router.navigate([''], { replaceUrl: true });
  }
}
