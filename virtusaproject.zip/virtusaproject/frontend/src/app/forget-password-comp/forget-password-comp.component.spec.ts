import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ForgetPasswordCompComponent } from './forget-password-comp.component';

describe('ForgetPasswordCompComponent', () => {
  let component: ForgetPasswordCompComponent;
  let fixture: ComponentFixture<ForgetPasswordCompComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ForgetPasswordCompComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ForgetPasswordCompComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
