import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserSampleCompComponent } from './user-sample-comp.component';

describe('UserSampleCompComponent', () => {
  let component: UserSampleCompComponent;
  let fixture: ComponentFixture<UserSampleCompComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserSampleCompComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserSampleCompComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
