package com.example.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.model.BloodSampleClass;

public interface BloodSampleInterface extends JpaRepository<BloodSampleClass,Integer> 
{

}
