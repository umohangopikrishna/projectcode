package com.example.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.model.UserTable;

public interface UserTableInterface extends JpaRepository<UserTable,Integer> {

} 
