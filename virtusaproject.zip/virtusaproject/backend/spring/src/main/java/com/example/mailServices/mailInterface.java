package com.example.mailServices;

import com.example.MailBeen.Mail;

public interface mailInterface {
	public void sendEmail(Mail mail);


}
