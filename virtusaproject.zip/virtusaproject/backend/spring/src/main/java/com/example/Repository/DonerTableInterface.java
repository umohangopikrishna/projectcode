package com.example.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.model.DonerClass;

public interface DonerTableInterface extends JpaRepository<DonerClass,Integer> {

}
