package com.example.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
@Entity
public class DonerClass {

	
	
	@Id
	@GeneratedValue
	int id;
	float weight;
    int age;
    String phoneNumber;
    String address;
    String pHLevel;
    String pressure;
    String bloodgroup;
    String donarName;
    
    public DonerClass() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    public DonerClass(int id, float weight, int age, String phoneNumber, String address, String pHLevel,
			String pressure, String bloodgroup, String donarName) {
		super();
		this.id = id;
		this.weight = weight;
		this.age = age;
		this.phoneNumber = phoneNumber;
		this.address = address;
		this.pHLevel = pHLevel;
		this.pressure = pressure;
		this.bloodgroup = bloodgroup;
		this.donarName = donarName;
	}
    
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public float getWeight() {
		return weight;
	}
	public void setWeight(float weight) {
		this.weight = weight;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getpHLevel() {
		return pHLevel;
	}
	public void setpHLevel(String pHLevel) {
		this.pHLevel = pHLevel;
	}
	public String getPressure() {
		return pressure;
	}
	public void setPressure(String pressure) {
		this.pressure = pressure;
	}
	public String getBloodgroup() {
		return bloodgroup;
	}
	public void setBloodgroup(String bloodgroup) {
		this.bloodgroup = bloodgroup;
	}
	public String getDonarName() {
		return donarName;
	}
	public void setDonarName(String donarName) {
		this.donarName = donarName;
	}
	
	
}
