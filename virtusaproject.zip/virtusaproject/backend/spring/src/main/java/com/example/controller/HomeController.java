package com.example.controller;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Repository.BloodSampleInterface;
import com.example.Repository.DonerTableInterface;
import com.example.Repository.UserTableInterface;
import com.example.model.BloodSampleClass;
import com.example.model.DonerClass;
import com.example.model.UserTable;

import com.example.MailBeen.*;
import com.example.mailServices.*;
// orgin = "http://localhost:8081"

@CrossOrigin(origins = "http://localhost:8081")
@RestController
public class HomeController {

	@Autowired
	private UserTableInterface userdataobj;
	
	@Autowired
	private DonerTableInterface donerdataobj;
	
	@Autowired
	private BloodSampleInterface bloodsampledataobj;

	@PostMapping(path= "/UserRegistration/",consumes = "application/json", produces = "application/json")
	public boolean[] UserRegistration(@RequestBody UserTable userinfodata) {
		
		System.out.println(userinfodata.getFirstName()+" "+userinfodata.getLastName());
		
		List<UserTable> userInfoList = userdataobj.findAll();
		boolean[] verfiy = new boolean[3];
		for(int i=0;i<userInfoList.size();i++)
		{
			if(userInfoList.get(i).getTypeUser().equals(userinfodata.getTypeUser())) 
			{
			if(userinfodata.getGmailId().equals(userInfoList.get(i).getGmailId()))
			{
				verfiy[0]=true;
			}
			if(userinfodata.getPhoneNumber().equals(userInfoList.get(i).getPhoneNumber()))
			{
				verfiy[1]=true;
			}
			if(userinfodata.getUserID().equals(userInfoList.get(i).getUserID()))
			{
				verfiy[2]=true;
			}
			
			if(verfiy[0] && verfiy[1] && verfiy[2])
			{
				return(verfiy);
			}
			}
		}
		
		if(verfiy[0] || verfiy[1] || verfiy[2])
		{
			return(verfiy);
		}else
		{
			//System.out.println(userinfodata.getFirstName()+" "+userinfodata.getLastName());
			userdataobj.save(userinfodata);
			
		}
		
		return(verfiy);
	}
	
	
	
@GetMapping("/UserLogin/{UserId}/{Password}/{typeUser}")
public boolean LoginUser(@PathVariable String UserId ,@PathVariable String Password ,@PathVariable String typeUser)
	{
		List<UserTable> userInfoList = userdataobj.findAll();
		System.out.println(UserId);
	//-------------------------------------------------------------------	
		LocalDateTime myDateObj = LocalDateTime.now();
		DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		String[] datedata1 = myDateObj.format(myFormatObj).split("-");
		int dd1 = Integer.parseInt(datedata1[0]);
		int mm1 = Integer.parseInt(datedata1[1]);
		int yy1 = Integer.parseInt(datedata1[2]);
		List<BloodSampleClass> sampleDateList = new ArrayList<>(bloodsampledataobj.findAll());	
		for(int i=0;i<sampleDateList.size();i++)
		{
			BloodSampleClass bloodSampleObj = sampleDateList.get(i);
			String[] datedata2 = bloodSampleObj.getPacketdate().split("/");
			int dd2 = Integer.parseInt(datedata2[0]);
			int mm2 =Integer.parseInt(datedata2[1]);
			int yy2 = Integer.parseInt(datedata2[2]);
			
			LocalDate start_date= LocalDate.of(yy2, mm2,dd2);
	        LocalDate end_date = LocalDate.of(yy1, mm1, dd1);
	        int numberofDaysTOExpier = findDifference(start_date,end_date);
	        System.out.println(numberofDaysTOExpier+" "+bloodSampleObj.getPacketdate());
	       if(numberofDaysTOExpier>90)
	       {
	    	   bloodsampledataobj.deleteById(bloodSampleObj.getId());
	       }
	       else
	       {
	    	   BloodSampleClass bloodSample =  bloodsampledataobj.findById(sampleDateList.get(i).getId()).get();
	    	   bloodSample.setDaysOfbloodPacket(numberofDaysTOExpier);
	    	   bloodsampledataobj.save(bloodSample);        
	       }
		}
 //-----------------------------------------------
		for(int i=0;i<userInfoList.size();i++)
		{
			if(userInfoList.get(i).getTypeUser().equals(typeUser)) 
			{
			  if(userInfoList.get(i).getUserID().equals(UserId) && userInfoList.get(i).getPassword().equals(Password))
			 {
				return(true);
			 }
			}
		}
		
		
		
		
		return(false);
	}


@PostMapping("/addDoner/")
public boolean addDoner(@RequestBody DonerClass donerData)
{

	List<DonerClass> donerList = donerdataobj.findAll();
	for(int i=0;i<donerList.size();i++)
	{
		if(donerList.get(i).getPhoneNumber().equals(donerData.getPhoneNumber()))
		{
			return(false);
		}
	}
	//System.out.println(donerData.getAddress());
	donerdataobj.save(donerData);
	return(true);
}
	
@DeleteMapping("/deleteDonar/{donerId}")
public boolean deleteDoner(@PathVariable int donerId)
{
	//System.out.println(donerId);
   try
   {
	   donerdataobj.deleteById(donerId);
	   return(true);
   }
   catch(Exception e)
   {
	   return(false);
   }
}

@PutMapping("/updateDoner/")
public boolean updateDoner(@RequestBody DonerClass donerData)
{

	int donerId = donerData.getId();
	System.out.println(donerId);
	try {
	DonerClass donerObj = donerdataobj.findById(donerId).get();
	 
	
	 donerObj.setWeight(donerData.getWeight());
	 donerObj.setAddress(donerData.getAddress());
	 donerObj.setAge(donerData.getAge());
	 donerObj.setBloodgroup(donerData.getBloodgroup());
	 donerObj.setPhoneNumber(donerData.getPhoneNumber());
	 donerObj.setDonarName(donerData.getDonarName());
	 donerObj.setpHLevel(donerData.getpHLevel());
	 donerObj.setPressure(donerData.getPressure());
	 
	 donerdataobj.save(donerObj);
	 return(true);
	}
	catch(Exception e)
	{
		return(false);
	}
}


@GetMapping("/getAllDoners/")
public List<DonerClass> getAllDoners()
{
	return(donerdataobj.findAll());
}




@PostMapping("/addSample/")
public boolean addSample(@RequestBody BloodSampleClass bloodSampleObj)
{

	
	System.out.println(bloodSampleObj.getAddress());
	try 
	{
	 bloodsampledataobj.save(bloodSampleObj);
      return(true);
	}
	catch(Exception e)
	{
		return( false);
	}
}



static int findDifference(LocalDate start_date, LocalDate end_date)
{

    // find the period between
    // the start and end date
    Period diff= Period.between(start_date,end_date);

    // Print the date difference
    // in years, months, and days
    

    // Print the result
   
        return(diff.getYears()*365 + diff.getMonths()*30 + diff.getDays());
}

@GetMapping("/getAllSamples/")
public List<BloodSampleClass> getAllSamples()
{
	return(bloodsampledataobj.findAll());
}

@DeleteMapping("/deleteSample/{sampleId}")
public boolean deleteSample(@PathVariable int sampleId)
{
	try {
	bloodsampledataobj.deleteById(sampleId);
	return(true);
	}
	catch(Exception e)
	{
		return(false);
	}
}

@PutMapping("/updateSampleData/")
public boolean updateSampleData(@RequestBody BloodSampleClass bloodSampleObj)
{
	int sampleId = bloodSampleObj.getId();
	System.out.println();
	try {
        
        BloodSampleClass bloodSampleUpdateObj = bloodsampledataobj.findById(sampleId).get();
        bloodSampleUpdateObj.setLocation(bloodSampleObj.getLocation());
		bloodSampleUpdateObj.setPacks(bloodSampleObj.getPacks());
	    bloodSampleUpdateObj.setPhoneNumber(bloodSampleObj.getPhoneNumber());
		bloodSampleUpdateObj.setAddress(bloodSampleObj.getAddress());
		bloodSampleUpdateObj.setPhlevel(bloodSampleObj.getPhlevel());
		bloodSampleUpdateObj.setPressure(bloodSampleObj.getPressure());
		bloodSampleUpdateObj.setBloodgroup(bloodSampleObj.getBloodgroup());
		bloodsampledataobj.save(bloodSampleUpdateObj);
        return(true);
	}
	catch(Exception e)
	{
		System.out.println(e);
		return(false);
	}
}

@GetMapping("/verfiyGmail/{gmail}/{typeUser}/")
public boolean verifyGmail(@PathVariable String gmail , @PathVariable String typeUser)
{

	List<UserTable> userList = userdataobj.findAll();
	
	for( int i=0;i<userList.size();i++)
	{
		if(userList.get(i).getGmailId().equals(gmail) && userList.get(i).getTypeUser().equals(typeUser))
		{
			return(true);
		}
	}
	return(false);
}

@GetMapping("/sendgmail/{typeUser}/{gmail}/{otp}/")
public String sendgmaile(@PathVariable String typeUser , @PathVariable String gmail , @PathVariable String otp)
{   
	 Mail mail = new Mail();
     mail.setMailFrom("BloodBank@gmail.com");
     mail.setMailTo(gmail);
    
    	 mail.setMailSubject("RESET YOUR Blood Bank PASSWORD");
    	 mail.setMailContent("<div style='padding:30px;background-color:rgb(248, 133, 133);border-radius: 20px;'><h1 style='color: red'> BLOOD BANK SAVE LIFE</h1>"
    	 		+ "<img src='https://th.bing.com/th/id/Racf3ba632d33544de206a3db287a41b0?rik=tzk0z7cB%2bd3L1Q&pid=ImgRaw' style='border-radius:10px;height:400px;width:400px;'" + "'>"
    	     		+ "<h3>Dear "+typeUser+"</h3><h4> Enter your OTP in ower Blood Bank website.  </h4><h4> OTP : "+otp+"</h4></div>");
         
     ApplicationContext  context = mail.getContext(); 
     mailInterface mailService = (mailInterface) context.getBean("mailService");
     System.out.println(context);
     mailService.sendEmail(mail);
     
     return("\"mail is send\"");
     
}

@GetMapping("/updatepassword/{gmail}/{password}")
public boolean updatepassword(@PathVariable String gmail, @PathVariable String password)
{
    List<UserTable> userList = userdataobj.findAll();
    try {
    for(int i=0;i<userList.size();i++)
    {
    	 if(userList.get(i).getGmailId().equals(gmail)) 
    	 {
    		 UserTable userObj =  userdataobj.findById(userList.get(i).getId()).get();
    		 userObj.setPassword(password);
    		 userdataobj.save(userObj);
    		 return(true);
    	 }
    	
    }
    }
    catch(Exception e)
    {
    	 return(false);
    }
    return(false);
}

@GetMapping("/getUserDataByUserId/{userid}/")
public UserTable getUserDataByUserId(@PathVariable String userid)
{
    List<UserTable> userdataList = userdataobj.findAll();
    for(int i=0;i<userdataList.size();i++)
       {
    	if(userid.equals(userdataList.get(i).getUserID()))
    	{
    		return(userdataList.get(i));
    	}
    	
	    }
    return(null);
}

@PostMapping("/updateprofile/")
public boolean[] updateUserProfile(@RequestBody UserTable userObj)
{
	boolean[] verfiy = new boolean[3];
	try 
	{
		int id = userObj.getId();
		
		
		
		List<UserTable> userInfoList = userdataobj.findAll();
		
		for(int i=0;i<userInfoList.size();i++)
		{
			if(userObj.getId() != userInfoList.get(i).getId())
			{
			if(userObj.getTypeUser().equals(userInfoList.get(i).getTypeUser())) 
			{
			if(userObj.getGmailId().equals(userInfoList.get(i).getGmailId()))
			{
				verfiy[0]=true;
			}
			if(userObj.getPhoneNumber().equals(userInfoList.get(i).getPhoneNumber()))
			{
				verfiy[1]=true;
			}
			if(userObj.getUserID().equals(userInfoList.get(i).getUserID()))
			{
				verfiy[2]=true;
			}
			
			if(verfiy[0] && verfiy[1] && verfiy[2])
			{
				return(verfiy);
			}
			}
			}
		}
		
		UserTable userData = userdataobj.findById(id).get();
		userData.setFirstName(userObj.getFirstName());
		userData.setGmailId(userObj.getGmailId());
		userData.setLastName(userObj.getLastName());
		userData.setPassword(userObj.getPassword());
		userData.setPhoneNumber(userObj.getPhoneNumber());
		userData.setUserID(userObj.getUserID());
		userdataobj.save(userData);
		return(verfiy);
	}
	catch(Exception e)
	{
		return(verfiy);
	}
	
}

@GetMapping("/data/")
public String getData()
	{
	
		return(userdataobj.findAll().get(0).getFirstName());
	}
}
