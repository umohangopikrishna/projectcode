package com.example.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class BloodSampleClass {

	
	
	

	@Id
	@GeneratedValue
	int id;
	String location;
	int packs;
	String packetdate;
	String phoneNumber;
	String address;
	float phlevel;
	float pressure;
	String bloodgroup;
	int daysOfbloodPacket;
	
	public BloodSampleClass() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BloodSampleClass(int id, String location, int packs, String packetdate, String phoneNumber, String address,
			float phlevel, float pressure, String bloodgroup) {
		super();
		this.id = id;
		this.location = location;
		this.packs = packs;
		this.packetdate = packetdate;
		this.phoneNumber = phoneNumber;
		this.address = address;
		this.phlevel = phlevel;
		this.pressure = pressure;
		this.bloodgroup = bloodgroup;
		
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public int getPacks() {
		return packs;
	}
	public void setPacks(int packs) {
		this.packs = packs;
	}
	public String getPacketdate() {
		return packetdate;
	}
	public void setPacketdate(String packetdate) {
		this.packetdate = packetdate;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public float getPhlevel() {
		return phlevel;
	}
	public void setPhlevel(float phlevel) {
		this.phlevel = phlevel;
	}
	public float getPressure() {
		return pressure;
	}
	public void setPressure(float pressure) {
		this.pressure = pressure;
	}
	public String getBloodgroup() {
		return bloodgroup;
	}
	public void setBloodgroup(String bloodgroup) {
		this.bloodgroup = bloodgroup;
	}
	public int getDaysOfbloodPacket() {
		return daysOfbloodPacket;
	}
	public void setDaysOfbloodPacket(int daysOfbloodPacket) {
		this.daysOfbloodPacket = daysOfbloodPacket;
	}
	
	
	
}
