package com.example.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;



@Entity
public class UserTable {
	
	
	
	

	@Id
	@GeneratedValue
	int id;
	String FirstName;
	String LastName;
	String PhoneNumber;
	String TypeUser;
	String Password;
	String GmailId;
	String UserID;
	
	public UserTable() {
		super();
		// TODO Auto-generated constructor stub
	}
	public UserTable(int id, String firstName, String lastName, String phoneNumber, String typeUser, String password,
			String gmailId, String userID) {
		super();
		this.id = id;
		FirstName = firstName;
		LastName = lastName;
		PhoneNumber = phoneNumber;
		TypeUser = typeUser;
		Password = password;
		GmailId = gmailId;
		UserID = userID;
	}


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	public String getPhoneNumber() {
		return PhoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		PhoneNumber = phoneNumber;
	}

	public String getTypeUser() {
		return TypeUser;
	}

	public void setTypeUser(String typeUser) {
		TypeUser = typeUser;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}

	public String getGmailId() {
		return GmailId;
	}

	public void setGmailId(String gmailId) {
		GmailId = gmailId;
	}
	public String getUserID() {
		return UserID;
	}
	public void setUserID(String userID) {
		UserID = userID;
	}
	

}
